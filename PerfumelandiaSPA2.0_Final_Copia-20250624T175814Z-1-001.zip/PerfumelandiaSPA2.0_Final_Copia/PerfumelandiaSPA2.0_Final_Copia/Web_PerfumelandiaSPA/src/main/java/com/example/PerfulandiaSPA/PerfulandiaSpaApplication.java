package com.example.PerfulandiaSPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfulandiaSpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfulandiaSpaApplication.class, args);
	}

}
