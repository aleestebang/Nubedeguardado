const API = "/api/v1/carrito";

async function agregarAlCarrito(id) {
    const res = await fetch(`${API}/agregar/${id}`, { method: "POST" });
    const msg = await res.text();
    alert(msg);
    actualizarStockYBotones();
    actualizarTotalCarrito();
}

async function actualizarStockYBotones() {
    // Supón que tienes un endpoint para obtener todos los perfumes con stock
    const res = await fetch("/api/v1/perfumes"); // Debes crear este endpoint si no existe
    const perfumes = await res.json();
    perfumes.forEach(p => {
        const stockSpan = document.getElementById(`stock-${p.idPerfume}`);
        const btn = document.getElementById(`btn-add-${p.idPerfume}`);
        if (stockSpan) stockSpan.innerText = p.stock;
        if (btn) btn.disabled = p.stock <= 0;
    });
}

async function actualizarTotalCarrito() {
    const res = await fetch(API);
    const productos = await res.json();
    let total = 0;
    productos.forEach(p => total += p.precioPerfume || 0);
    document.getElementById('total-price').innerText = total.toLocaleString();
}

const carrito = (() => {
    const STORAGE_KEY = "carritoPerfumes";

    function obtenerCarrito() {
        return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    }

    function guardarCarrito(carrito) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(carrito));
    }

    function listarCarrito() {
        const carrito = obtenerCarrito();
        const tbody = document.querySelector("#tableCarrito tbody");
        const totalSpan = document.getElementById("TotalCarrito");
        tbody.innerHTML = "";
        let total = 0;

        carrito.forEach(perfume => {
            total += perfume.precio;
            const fila = `
                <tr>
                    <td>${perfume.id}</td>
                    <td>${perfume.nombre}</td>
                    <td>${perfume.marca}</td>
                    <td>$${perfume.precio.toLocaleString()}</td>
                    <td>
                        <button class="btn btn-eliminar" onclick="carrito.eliminarPerfume(${perfume.id})">Eliminar</button>
                    </td>
                </tr>
            `;
            tbody.innerHTML += fila;
        });

        totalSpan.textContent = carrito.length;
    }

    function agregarPerfume(perfume) {
        const carrito = obtenerCarrito();
        carrito.push(perfume);
        guardarCarrito(carrito);
        listarCarrito();
    }

    function eliminarPerfume(id) {
        let carrito = obtenerCarrito();
        carrito = carrito.filter(p => p.id !== id);
        guardarCarrito(carrito);
        listarCarrito();
    }

    function vaciarCarrito() {
        if (confirm("¿Estás seguro de vaciar el carrito?")) {
            guardarCarrito([]);
            listarCarrito();
        }
    }

    function confirmarCompra() {
        const carrito = obtenerCarrito();
        if (carrito.length === 0) {
            alert("El carrito está vacío.");
            return;
        }
        if (confirm("¿Desea confirmar la compra?")) {
            guardarCarrito([]);
            listarCarrito();
            alert("¡Gracias por tu compra!");
        }
    }

    // Exponer funciones globalmente
    return { listarCarrito, agregarPerfume, eliminarPerfume, vaciarCarrito, confirmarCompra };
})();

// Inicializar al cargar la página
document.addEventListener("DOMContentLoaded", () => {
    carrito.listarCarrito();
    actualizarStockYBotones();
    actualizarTotalCarrito();
});
