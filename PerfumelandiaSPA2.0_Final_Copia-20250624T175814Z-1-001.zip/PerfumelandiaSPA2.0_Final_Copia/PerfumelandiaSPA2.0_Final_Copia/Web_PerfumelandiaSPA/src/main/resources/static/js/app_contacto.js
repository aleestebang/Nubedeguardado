function enviar(){
    alert('Mensaje enviado');
    document.getElementById('exampleFormControlInput1').value = '';
    document.getElementById('exampleFormControlTextarea1').value = '';
    document.getElementById('exampleFormControlInput1').focus();
};