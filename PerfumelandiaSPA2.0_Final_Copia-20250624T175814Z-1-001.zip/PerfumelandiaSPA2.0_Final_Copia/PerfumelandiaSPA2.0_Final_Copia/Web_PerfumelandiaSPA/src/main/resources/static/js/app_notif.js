const notificaciones = (() => {
    const API = "/api/v1/notificaciones";

    async function listarNotificaciones() {
        try {
            const response = await fetch(API);
            const notis = await response.json();
            const tbody = document.querySelector("#tablaNotificaciones tbody");
            const totalSpan = document.getElementById("totalNotificaciones");

            tbody.innerHTML = "";
            totalSpan.textContent = notis.length;

            notis.forEach(noti => {
                const fila = `
                    <tr>
                        <td>${noti.id}</td>
                        <td>${noti.titulo}</td>
                        <td>${noti.mensaje}</td>
                        <td>${noti.fecha}</td>
                        <td>
                            <button class="btn btn-sm btn-danger" onclick="notificaciones.eliminarNotificacion(${noti.id})">🗑</button>
                        </td>
                    </tr>
                `;
                tbody.innerHTML += fila;
            });
        } catch (err) {
            console.error("Error al cargar notificaciones", err);
        }
    }

    async function agregarNotificacion(data) {
        try {
            await fetch(`${API}/agregar`, {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(data)
            });
            alert("Notificación agregada");
            listarNotificaciones();
        } catch (err) {
            console.error("Error al agregar notificación", err);
        }
    }

    async function eliminarNotificacion(id) {
        try {
            await fetch(`${API}/eliminar/${id}`, { method: "DELETE" });
            alert("Notificación eliminada");
            listarNotificaciones();
        } catch (err) {
            console.error("Error al eliminar notificación", err);
        }
    }

    async function vaciarNotificaciones() {
        if (confirm("¿Estás seguro de eliminar todas las notificaciones?")) {
            await fetch(`${API}/vaciar`, { method: "DELETE" });
            alert("Todas las notificaciones fueron eliminadas");
            listarNotificaciones();
        }
    }

    return {
        listarNotificaciones,
        agregarNotificacion,
        eliminarNotificacion,
        vaciarNotificaciones
    };
})();

document.addEventListener("DOMContentLoaded", () => {
    notificaciones.listarNotificaciones();
});
