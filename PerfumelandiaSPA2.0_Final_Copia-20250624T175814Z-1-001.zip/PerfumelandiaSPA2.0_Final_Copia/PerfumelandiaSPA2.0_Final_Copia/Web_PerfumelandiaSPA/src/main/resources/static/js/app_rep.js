const reportes = (() => {
    const API = "/api/v1/reportes";

    async function listarReportes() {
        try {
            const response = await fetch(API);
            const reps = await response.json();
            const tbody = document.querySelector("#tablaReportes tbody");
            const totalSpan = document.getElementById("totalReportes");

            tbody.innerHTML = "";
            totalSpan.textContent = reps.length;

            reps.forEach(rep => {
                const fila = `
                    <tr>
                        <td>${rep.id}</td>
                        <td>${rep.titulo}</td>
                        <td>${rep.descripcion}</td>
                        <td>${rep.fecha}</td>
                        <td>
                            <button class="btn btn-sm btn-danger" onclick="reportes.eliminarReporte(${rep.id})">🗑</button>
                        </td>
                    </tr>
                `;
                tbody.innerHTML += fila;
            });
        } catch (err) {
            console.error("Error al cargar reportes", err);
        }
    }

    async function agregarReporte(data) {
        try {
            await fetch(`${API}/agregar`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });
            alert("Reporte agregado");
            listarReportes();
        } catch (err) {
            console.error("Error al agregar reporte", err);
        }
    }

    async function eliminarReporte(id) {
        try {
            await fetch(`${API}/eliminar/${id}`, { method: "DELETE" });
            alert("Reporte eliminado");
            listarReportes();
        } catch (err) {
            console.error("Error al eliminar reporte", err);
        }
    }

    async function vaciarReportes() {
        if (confirm("¿Estás seguro de eliminar todos los reportes?")) {
            try {
                await fetch(`${API}/vaciar`, { method: "DELETE" });
                alert("Todos los reportes fueron eliminados");
                listarReportes();
            } catch (err) {
                console.error("Error al vaciar reportes", err);
            }
        }
    }

    return {
        listarReportes,
        agregarReporte,
        eliminarReporte,
        vaciarReportes
    };
})();

document.addEventListener("DOMContentLoaded", () => {
    reportes.listarReportes();
});
